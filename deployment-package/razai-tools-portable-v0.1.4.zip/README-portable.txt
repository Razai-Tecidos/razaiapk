Razai Tools Portable

Versão: v0.1.4
Arquivo: razai-tools-v0.1.4.exe
SHA256: 93c1cba0d86cc16cb0b3d05059af5ceeebce474a1d35384b90a1b2e9e964dbdc

Requisitos:
- Windows 10+
- Runtime WebView2 (se não instalado, o Windows deve baixar automaticamente; caso contrário instalar manualmente: https://developer.microsoft.com/en-us/microsoft-edge/webview2/ )

Uso:
1. Extraia o zip em qualquer pasta.
2. Dê duplo clique no executável.
3. Para atualizar, substitua o exe por uma versão mais recente.

Observações:
- Dados locais ficam em %APPDATA%/razai-tools (SQLite).
- Faça backup via tela Exportações / Configurações antes de trocar a versão se necessário.

